# Portable navy UI visual evidence

This frozen package preserves the existing evidence for Agent Core source commit
`d3e9272c090136ff8f0de6aec3849c9d59d5b18b`. It adds no new UI acceptance claim.

1. Extract the complete archive into an empty directory.
2. Run `python3 verify.py` there to verify every capture and evidence record.
3. Open `index.html` in a browser. It uses local files only; no application,
   provider credentials, package installation or network connection is needed.

`manifest.json` maps original `/tmp/agent-core-navy` provenance to relative archive
paths, preserving original PNG bytes, SHA-256 hashes, viewport metadata, source
epoch digests and recorded reviewers. The old absolute paths are provenance only;
all gallery links use the relative `path` field.

Final selections prefer array-correction over office-confirmation over confirmation
when filenames repeat. All earlier, baseline and supplemental captures are retained
separately, including superseded defects. Selection does not mean every state was
independently reviewed. See recorded reviewers, source epochs and the independent
reports for exact inspection limits. Captures support visual review, not functional,
production, physical-device, real-provider or universal accessibility certification.

The records directory contains the original coverage, verification and review
records unchanged. Their historical absolute references resolve via manifest.json.
