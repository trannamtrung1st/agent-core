from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
records = manifest['images'] + manifest['metadata']
errors = []
for record in records:
    file = (root / record['path']).resolve()
    if not file.is_relative_to(root) or not file.is_file():
        errors.append(record['path'] + ': missing/invalid path')
    elif hashlib.sha256(file.read_bytes()).hexdigest() != record['sha256']:
        errors.append(record['path'] + ': SHA-256 mismatch')
if errors:
    raise SystemExit('\n'.join(errors))
print(f"Verified {len(manifest['images'])} original PNGs and {len(manifest['metadata'])} evidence records.")
